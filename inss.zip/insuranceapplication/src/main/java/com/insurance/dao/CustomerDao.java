package com.insurance.dao;

import java.util.List;

import com.insurance.model.Insurance;



public interface CustomerDao {
	public List<Insurance> getAllInsurances();
	public List<Insurance> getAllHealthInsurances();
	public void addInsurance(Insurance i);
	public void save(Insurance insurance);
    public Insurance updateEmployee(Insurance insurance);
	public Insurance findCustomerId(int id);
	public void delete(int id);
	
}



