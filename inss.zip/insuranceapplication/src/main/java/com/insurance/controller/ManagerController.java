package com.insurance.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.insurance.model.Insurance;
import com.insurance.service.CustomerService;

@Controller
public class ManagerController {

	@Autowired
	private CustomerService customerService;


	@RequestMapping("/insurances")
	public String listStudents(Model model) {
		List<Insurance> studentList = customerService.getAllInsurances();
		model.addAttribute("listInsurance", studentList);
		return "insurances";
	}




	@GetMapping("/viewinsurances")
	public String listStudents1(Model model) {
		List<Insurance> healthInsurances = customerService.getAllHealthInsurances();
		model.addAttribute("listInsurance", healthInsurances);
		return "availableinsurances";
	}
	
	

	@RequestMapping("/newinsurance")
	public String newCustomerForm1(Map<String, Object> model) {
		Insurance insurance = new Insurance();
		model.put("insurance", insurance);
		return "new_insurance";
	}
	
	

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ModelAndView saveCustomer(@ModelAttribute Insurance insurance){
		customerService.addInsurance(insurance);
		ModelAndView mv = new ModelAndView();
		List<Insurance> studentList = customerService.getAllInsurances();
		mv.addObject("listInsurance", studentList);
		mv.setViewName("insurances");
		return mv;
	}
	
	
	@RequestMapping(value="delete/{id}")
	public String deleteCourse(@PathVariable("id") String id) {

		int i = Integer.parseInt(id);
		customerService.delete(i);
		return "redirect:/insurances.mvc";
	}
		
	}

//@RequestMapping("/edit")
//public ModelAndView editdetails(@RequestParam("id") int id) {
//
//	ModelAndView mv = new ModelAndView("/edit", "insurance", new Insurance());
//	Insurance insurance = insurance.(id);
//	mv.addObject("u", insurance);
//
//	return mv;
//}

	
	
	
	
	
	
	
	
	
	
//	@RequestMapping(value = "/edit", method = RequestMethod.POST)
//	public ModelAndView editCustomer(@ModelAttribute Insurance insurance) {
//		customerService.(insurance);
//		ModelAndView mv = new ModelAndView();
//		List<Insurance> studentList = customerService.getAllInsurances();
//		mv.addObject("listInsurance", studentList);
//		mv.setViewName("insurances");
//		return mv;
//	}
//    @RequestMapping(value = "/deleteEmployee", method = RequestMethod.GET)
//    public ModelAndView deleteEmployee(HttpServletRequest request) {
//        int employeeId = Integer.parseInt(request.getParameter("id"));
//        employeeService.deleteEmployee(employeeId);
//        return new ModelAndView("redirect:/");
//    }
//
//    @RequestMapping(value = "/deleteEmployee", method = RequestMethod.GET)
//    public ModelAndView deleteEmployee(HttpServletRequest request) {
//        int employeeId = Integer.parseInt(request.getParameter("id"));
//        employeeService.deleteEmployee(employeeId);
//        return new ModelAndView("redirect:/");
//    }
	
//    @RequestMapping(value = "/editEmployee", method = RequestMethod.GET)
//    public ModelAndView editContact(HttpServletRequest request) {
//        int id = Integer.parseInt(request.getParameter("id"));
//        Insurance insurance = customerService.findCustomerId(id);
//        employeeService.updateEmployee(employee);
//        ModelAndView model = new ModelAndView("InsuranceForm");
//        model.addObject("employee", insurance);
// 
//        return model;
//    }



