package com.insurance.controller;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


import org.springframework.web.bind.annotation.ModelAttribute; //new
import org.springframework.validation.BindingResult; //new

// using @ModelAttribute
import com.insurance.model.*;
import com.insurance.model.User;
@Controller
public class UserController2 {

    private static final String[] countries = { "Turkey", "United States", "Germany" };


	@RequestMapping(value = "/form2")
	public ModelAndView user() {
		//ModelAndView modelAndView = new ModelAndView("userForm", "user", new User());
		ModelAndView modelAndView = new ModelAndView("userForm");
		modelAndView.addObject("genders", Gender.values());
		modelAndView.addObject("countries", countries);
		
		return modelAndView;
	}

	@RequestMapping(value = "/result2")
	//public ModelAndView processUser(User user) {
	public ModelAndView processUser(@ModelAttribute("user") User user, BindingResult result, ModelAndView modelAndView) {
		//ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("userResult");
		modelAndView.addObject("u", user);
		return modelAndView;
	}
	
	@ModelAttribute("user")
	public User populateUser(){
		User user = new User();
		user.setName("Default name");
		return user;
	}
	
}