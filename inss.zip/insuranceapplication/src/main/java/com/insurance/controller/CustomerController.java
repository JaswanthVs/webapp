package com.insurance.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.insurance.model.Insurance;
import com.insurance.service.CustomerService;

@Controller
public class CustomerController {
	


	@RequestMapping(value = "/hello", method = RequestMethod.GET)
	public ModelAndView sayHello() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("customer_home");
		return mv;
	}
	
	@RequestMapping("/logout")
	public ModelAndView logout() {
	ModelAndView mv = new ModelAndView();

	mv.setViewName("index1");
		return mv;	
	}

	@GetMapping("/home")
	public ModelAndView goHome() {
		ModelAndView mv = new ModelAndView();

		mv.setViewName("customer_home");
		return mv;
	}

	
	@GetMapping(value = "/manager")
	public ModelAndView sayHello1() {
		ModelAndView mv = new ModelAndView();

		mv.setViewName("Managerscreen");
		return mv;
	}
	

}