package com.insurance.controller;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.insurance.model.*;
import com.insurance.model.User;


// import org.springframework.web.bind.annotation.ModelAttribute; //new
// import org.springframework.validation.BindingResult; 

// using @ModelAttribute

@Controller
public class UserController {

    private static final String[] countries = { "Andhra Pradesh", "Tamil Nadu", "Karnataka"};


	@RequestMapping(value = "/form")
	public ModelAndView user() {
		ModelAndView modelAndView = new ModelAndView("userForm", "user", new User());
		modelAndView.addObject("genders", Gender.values());
		modelAndView.addObject("countries", countries);
		
		return modelAndView;
	}

	@RequestMapping(value = "/result")
	public ModelAndView processUser(User user) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("userResult");
		
//		user.setName("Hi Nikhil");
		
		modelAndView.addObject("u", user);
		
		return modelAndView;
	}	
	
}