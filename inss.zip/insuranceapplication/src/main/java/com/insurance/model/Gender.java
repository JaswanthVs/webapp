package com.insurance.model;

public enum Gender {
	Male,
	Female;
	
}
