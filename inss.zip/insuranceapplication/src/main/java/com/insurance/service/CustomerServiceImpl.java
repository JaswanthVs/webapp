package com.insurance.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.insurance.dao.CustomerDao;
import com.insurance.model.Insurance;



@Service
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	private CustomerDao customerdao;

	
	@Transactional
	public List<Insurance> getAllInsurances() {
		
		return customerdao.getAllInsurances();
	}
	
	@Transactional
	public List<Insurance> getAllHealthInsurances() {
		
		return customerdao.getAllHealthInsurances();
	}
	
	
	@Transactional
	public void addInsurance(Insurance i) {
		customerdao.addInsurance(i);
		
	}

    @Transactional
	public void save(Insurance insurance) {
		customerdao.save(insurance);
		
	}
    
    public Insurance updateEmployee(Insurance insurance) {
        return customerdao.updateEmployee(insurance);
    }


	public Insurance findCustomerId(int id) {
		return customerdao.findCustomerId(id);
	}



		
	@Transactional
	public void delete(int id) {
		customerdao.delete(id);
		
	}
	

}
